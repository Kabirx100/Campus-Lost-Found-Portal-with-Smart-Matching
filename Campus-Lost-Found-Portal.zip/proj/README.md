# Campus Lost & Found Portal with Smart Matching

A web app where students report lost and found items on campus. A smart matching engine compares every lost report with found reports and suggests the most likely matches.

## Features
- Register / login (Student and Admin roles)
- Report lost or found items with photo, category, location and date
- Browse and search all open items with filters
- Smart matching: ranked matches with a % score and reasons
- Ownership claims with proof, reviewed by an admin
- Contact details hidden until a claim is approved
- Admin dashboard: approve/reject claims, delete items
- My Reports page with match counts and claim status

## How smart matching works
Each lost/found pair gets a score out of 100:

| Signal | Weight | Method |
|---|---|---|
| Text similarity | 55% | TF-IDF + cosine similarity (scikit-learn) on title + description |
| Category | 20% | Same category = 1, else 0 |
| Location | 15% | Word overlap between the two location texts |
| Date closeness | 10% | Found on/after lost date, decays over 30 days |

Matches under 25% are hidden. See `matcher.py`.

## Tech
Python, Flask, scikit-learn, SQLite, HTML/CSS/Bootstrap.

## Run locally
```
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

Default admin: `admin@campus.edu` / `admin123` (change before real use).

## Structure
```
app.py            routes and logic
database.py       SQLite schema + admin seed
matcher.py        smart matching engine
templates/        HTML pages
static/           CSS and uploaded images
```
