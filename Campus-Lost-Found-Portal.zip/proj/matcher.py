"""Smart matching engine.

Compares a lost item against found items (or vice versa) and gives each pair
a score from 0-100 using four signals:

  55%  text similarity   - TF-IDF + cosine similarity on title/description
  20%  category match    - same category = 1, else 0
  15%  location overlap  - word overlap between the two location strings
  10%  date closeness    - found date should be on/after lost date, within 30 days
"""
import re
from datetime import datetime

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

W_TEXT, W_CATEGORY, W_LOCATION, W_DATE = 0.55, 0.20, 0.15, 0.10
MIN_SCORE = 25  # percent; matches below this are not shown


def _doc(item):
    # Title is repeated so it counts more than the description
    return f"{item['title']} {item['title']} {item['description'] or ''} {item['category']}".lower()


def _tokens(text):
    return set(re.findall(r'[a-z0-9]+', (text or '').lower()))


def _location_score(a, b):
    ta, tb = _tokens(a), _tokens(b)
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta | tb)


def _date_score(lost_date, found_date):
    try:
        lost = datetime.strptime(lost_date, '%Y-%m-%d')
        found = datetime.strptime(found_date, '%Y-%m-%d')
    except (TypeError, ValueError):
        return 0.0
    diff = (found - lost).days
    if diff < -1:          # found before it was lost: unlikely to be the same item
        return 0.0
    return max(0.0, 1 - max(diff, 0) / 30)


def find_matches(item, candidates, min_score=MIN_SCORE):
    """Return candidates ranked by similarity to `item`.

    `candidates` must be items of the opposite type (lost <-> found).
    Each result: {'item': row, 'score': int, 'reasons': [str, ...]}
    """
    if not candidates:
        return []

    docs = [_doc(item)] + [_doc(c) for c in candidates]
    try:
        tfidf = TfidfVectorizer(stop_words='english', ngram_range=(1, 2)).fit_transform(docs)
        text_scores = cosine_similarity(tfidf[0:1], tfidf[1:])[0]
    except ValueError:      # e.g. every word was a stop word
        text_scores = [0.0] * len(candidates)

    results = []
    for cand, text_s in zip(candidates, text_scores):
        cat_s = 1.0 if cand['category'] == item['category'] else 0.0
        loc_s = _location_score(item['location'], cand['location'])
        if item['type'] == 'lost':
            date_s = _date_score(item['event_date'], cand['event_date'])
        else:
            date_s = _date_score(cand['event_date'], item['event_date'])

        total = W_TEXT * text_s + W_CATEGORY * cat_s + W_LOCATION * loc_s + W_DATE * date_s
        score = round(total * 100)
        if score < min_score:
            continue

        reasons = []
        if text_s >= 0.2:
            reasons.append('Similar description')
        if cat_s:
            reasons.append(f"Same category ({item['category']})")
        if loc_s > 0:
            reasons.append('Nearby / same location')
        if date_s >= 0.5:
            reasons.append('Dates are close')
        results.append({'item': cand, 'score': score, 'reasons': reasons})

    results.sort(key=lambda r: r['score'], reverse=True)
    return results
